﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cadastro_Aluno.Modelos;
using MySql.Data.MySqlClient;

namespace Cadastro_Aluno.dao
{
    internal class ModeloDao
    {
        public void insert(Modelo modelo)
        {



            try
            {
                string sql = "INSERT INTO modelos(descricao, eixo, peso, passageiro, cavalo, cilindradas, fk_marca_id) " +
                    "VALUES(@descricao, @eixo, @peso, @passageiro, @cavalo, @cilindradas, @fk_marca_id)";
                MySqlCommand command = new MySqlCommand(sql, Conexao.Conectar());
                command.Parameters.AddWithValue("@descricao", modelo.descricao);
                command.Parameters.AddWithValue("@eixo", modelo.eixo);
                command.Parameters.AddWithValue("@peso", modelo.peso);
                command.Parameters.AddWithValue("@passageiro", modelo.passageiro);
                command.Parameters.AddWithValue("@cavalo", modelo.cavalo);
                command.Parameters.AddWithValue("@cilindradas", modelo.cilindrada);
                command.Parameters.AddWithValue("@fk_marca_id", modelo.fk_marca_id);
                command.ExecuteNonQuery();
                Console.WriteLine("Modelo de veiculo cadastrado com sucesso!");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao cadastrar Modelo!" + ex.Message);

            }
            finally
            {
                Conexao.FecharConexao();
            }


        }
        public void Delete(Modelo modelo)
        {
            try
            {
                string sql = "DELETE FROM Modelo Where id_modelo = @id_modelo";
                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
                comando.Parameters.AddWithValue("@id_modelo", modelo.id_modelo);
                comando.ExecuteNonQuery();
                Console.WriteLine("Medelo excluido com sucesso!");
                Conexao.FecharConexao();
            }
            catch (Exception ex)
            {

                throw new Exception($"Erro ao excluir um Modelo {ex.Message}");
            }
            finally
            {
                Conexao.FecharConexao();
            }

        }

        public List<Modelo> List()
        {
            List<Modelo> modelos = new List<Modelo>();
            try
            {
                var sql = "SELECT * FROM Modelo ORDER BY nome";
                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
                using (MySqlDataReader dr = comando.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Modelo modelo = new Modelo();
                        modelo.id_modelo = dr.GetInt32("id_modelo");
                        modelo.descricao = dr.GetString("descricao");
                        modelo.eixo = dr.GetString("eixo");
                        modelo.peso = dr.GetString("peso");
                        modelo.passageiro = dr.GetString("passageiro");
                        modelo.cavalo = dr.GetString("cavalo");
                        modelo.cilindrada = dr.GetString("cilindrada");
                        modelo.fk_marca_id = dr.GetInt32("fk_marca_id");
                        modelos.Add(modelo);



                    }

                }
                Conexao.FecharConexao();
            }
            catch (Exception ex)
            {

                throw new Exception($"Erro ao listar os Modelos! {ex.Message}");
            }
            return modelos;
        }
        public void Update(Modelo modelo)
        {
            try
            {
                string sql = "UPDATE Modelo SET descricao = @descricao, @eixo, @peso, @passageiro, @cavalo, @cilindradas, @fk_marca_id";
                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
                comando.Parameters.AddWithValue("@descricao", modelo.descricao);
                comando.Parameters.AddWithValue("@eixo", modelo.eixo);
                comando.Parameters.AddWithValue("@peso", modelo.peso);
                comando.Parameters.AddWithValue("@passageiro", modelo.passageiro);
                comando.Parameters.AddWithValue("@cavalo", modelo.cavalo);
                comando.Parameters.AddWithValue("@cilindradas", modelo.cilindrada);
                comando.Parameters.AddWithValue("@fk_marca_id", modelo.fk_marca_id);
                comando.ExecuteNonQuery();
                Console.WriteLine("Modelo de Veiculo atualizado com sucesso!");
                Conexao.FecharConexao();
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao atualizar modelode veiculo {ex.Message}");
            }
        }

        public void Menu()
        {
            int opcao;

            do
            {

                ModeloDao adao = new ModeloDao();

                Console.WriteLine("Escolha uma operação:");
                Console.WriteLine("1 - Inserir Modelo \n 2 - Deletar Modelo \n3 - Listar Modelos \n4 - Atualizar Modelo \n0 - Para sair do programa  ");
                opcao = int.Parse(Console.ReadLine());

                List<Modelo> modelotodos = adao.List();

                switch (opcao)
                {
                    case 1:
                        try
                        {
                            Modelo novomod = new Modelo();

                            Console.WriteLine("Insira a descrição do Modelo: ");
                            novomod.descricao = Console.ReadLine();

                            Console.WriteLine("Insira a quantidade de eixo: ");
                            novomod.descricao = Convert.ToString(Console.ReadLine());

                            Console.WriteLine("Insira o peso do veiculo: ");
                            novomod.peso = Convert.ToString(Console.ReadLine());

                            Console.WriteLine("Insira a quantidade de passageiros: ");
                            novomod.passageiro = Convert.ToString(Console.ReadLine());

                            Console.WriteLine("Insira a quantidade de cavalos do veiculo:");
                            novomod.cavalo = Convert.ToString(Console.ReadLine());

                            Console.WriteLine("Insira a quantidade de cilindradas:");
                            novomod.cilindrada = Convert.ToString(Console.ReadLine());

                        }
                        catch (Exception ex)
                        {
                            throw new Exception("Erro ao inserir Modelo!" + ex.Message);
                        }

                        break;

                    case 2:

                        Console.WriteLine("Digite qual ID deseja deletar:");

                        int a = Convert.ToInt32(Console.ReadLine());

                        Modelo deletarModelo = modelotodos.First(x => x.id_modelo == a);

                        adao.Delete(deletarModelo);

                        break;

                    case 3:
                        foreach (Modelo modelo3 in modelotodos)
                        {
                            Console.WriteLine($"Descrição: {modelo3.descricao}");
                            Console.WriteLine($"Eixo: {modelo3.eixo}");
                            Console.WriteLine($"Peso: {modelo3.peso}");
                            Console.WriteLine($"Passageiro: {modelo3.passageiro}");
                            Console.WriteLine($"Cavalo: {modelo3.cavalo}");
                            Console.WriteLine($"Cilindradas: {modelo3.cilindrada}");

                        }
                        break;

                    case 4:
                        Console.WriteLine("Digite qual ID deseja atualizar:");

                        int b = Convert.ToInt32(Console.ReadLine());

                        Modelo atualizaModelo = modelotodos.First(x => x.id_modelo == b);

                        if (atualizaModelo != null)
                        {
                            try
                            {
                                Console.WriteLine("Insira uma nova descrição, ou deixe em branco para manter o de antes:");
                                string descricao = Console.ReadLine();
                                if (!string.IsNullOrEmpty(descricao))
                                {
                                    atualizaModelo.descricao = descricao;
                                }

                                Console.WriteLine("Insira uma nova quantidade de eixo, ou deixe em branco para manter oque estava antes:");
                                string eixo = Console.ReadLine();
                                if (!string.IsNullOrEmpty(eixo))
                                {
                                    atualizaModelo.descricao = eixo;
                                }

                                Console.WriteLine("Insira um novo peso, ou deixe em branco para manter oque estava antes:");
                                string peso = Console.ReadLine();
                                if (!string.IsNullOrEmpty(peso))
                                {
                                    atualizaModelo.peso = Console.ReadLine();
                                }

                                Console.WriteLine("Insira uma nova quantidade de passageiro, ou deixe em branco para manter oque estava antes:");
                                string passageiro = Console.ReadLine();
                                if (!string.IsNullOrEmpty(passageiro))
                                {
                                    atualizaModelo.passageiro = Console.ReadLine();
                                }

                                Console.WriteLine("Insira uma nova quantidade de cavalos , ou deixe em branco para manter oque estava antes:");
                                string cavalo = Console.ReadLine();
                                if (!string.IsNullOrEmpty(cavalo))
                                {
                                    atualizaModelo.cavalo = Console.ReadLine();
                                }

                                Console.WriteLine("Insira uma quantidade de Cilindradas, ou deixe em branco para manter oque estava antes:");
                                string cilindrada = Console.ReadLine();
                                if (!string.IsNullOrEmpty(cilindrada))
                                {
                                    atualizaModelo.cilindrada = Console.ReadLine();
                                }

                                adao.Update(atualizaModelo);

                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Erro ao atualizar o Modelo: " + ex.Message);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Modelo não encontrado. Verifique o ID informado.");
                        }

                        break;

                    case 0:

                        break;
                    default:
                        break;

                }


            } while (opcao != 0);
        }
    }
}
