﻿using Cadastro_Aluno.dao;
using Cadastro_Aluno.Modelos;
using Cadastro_Aluno;

ModeloDao mode1 = new ModeloDao();

mode1.Menu();